Internet Technologies - Ex1
Nir Erez	301863858	nir2292

CSS styles I used:

background-color
border
border-radius
box-shadow
color
float
opacity
padding
transform
transition

HTML tags I used:

title
div
fieldset
label
input
figure
img
p
h1
table
